// Quiz Data - TCS Smart Hiring Preparation Paper No 10
const quizData = [
    {
        id: 1,
        question: "The arithmetic mean of the 12 consecutive integers starting with x is: What is the arithmetic mean of 12 consecutive integers that start with x + 2?",
        options: ["A. x", "B. x + 1", "C. x + 6", "D. x + 7"],
        correct: 3
    },
    {
        id: 2,
        question: "A company has 15 employees. If 5 employees are selected for a project, how many different teams can be formed?",
        options: ["A. 3003", "B. 2730", "C. 3003", "D. 360360"],
        correct: 0
    },
    {
        id: 3,
        question: "What is the next number in the series: 2, 6, 12, 20, 30, ?",
        options: ["A. 40", "B. 42", "C. 44", "D. 46"],
        correct: 1
    },
    {
        id: 4,
        question: "If CODING is written as DPEJOH, how is PYTHON written in that code?",
        options: ["A. QZUIPO", "B. QAUIPO", "C. QZUIOP", "D. QAUIOP"],
        correct: 0
    },
    {
        id: 5,
        question: "A train travels at 60 km/h for 2 hours and then at 80 km/h for 3 hours. What is the average speed?",
        options: ["A. 70 km/h", "B. 72 km/h", "C. 74 km/h", "D. 76 km/h"],
        correct: 1
    },
    {
        id: 6,
        question: "In a class of 50 students, 30 play cricket, 25 play football, and 10 play both. How many play neither?",
        options: ["A. 5", "B. 10", "C. 15", "D. 20"],
        correct: 0
    },
    {
        id: 7,
        question: "What is the value of log₂(64)?",
        options: ["A. 4", "B. 5", "C. 6", "D. 7"],
        correct: 2
    },
    {
        id: 8,
        question: "A person invests ₹10,000 at 10% simple interest per annum. What will be the total amount after 3 years?",
        options: ["A. ₹12,000", "B. ₹13,000", "C. ₹13,310", "D. ₹14,000"],
        correct: 1
    },
    {
        id: 9,
        question: "If 3x + 5 = 20, what is the value of 6x + 10?",
        options: ["A. 30", "B. 35", "C. 40", "D. 45"],
        correct: 2
    },
    {
        id: 10,
        question: "What is the least common multiple (LCM) of 12, 15, and 20?",
        options: ["A. 60", "B. 80", "C. 120", "D. 180"],
        correct: 2
    }
];

// State Variables
let currentQuestion = 0;
let selectedAnswers = {};
let markedQuestions = new Set();
let timeLeft = 45 * 60; // 45 minutes in seconds
let timerInterval;

// Initialize Quiz
function initQuiz() {
    renderQuestionGrid();
    loadQuestion();
    startTimer();
    updateStats();
}

// Start Timer
function startTimer() {
    timerInterval = setInterval(() => {
        timeLeft--;
        updateTimerDisplay();
        
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            submitQuiz();
        }
    }, 1000);
}

// Update Timer Display
function updateTimerDisplay() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    const timerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    document.getElementById('timer').textContent = timerText;
}

// Render Question Grid
function renderQuestionGrid() {
    const grid = document.getElementById('questionGrid');
    grid.innerHTML = '';
    
    quizData.forEach((_, index) => {
        const btn = document.createElement('button');
        btn.className = 'question-number';
        btn.textContent = index + 1;
        btn.onclick = () => jumpToQuestion(index);
        grid.appendChild(btn);
    });
    
    updateQuestionGrid();
}

// Update Question Grid Colors
function updateQuestionGrid() {
    const buttons = document.querySelectorAll('.question-number');
    
    buttons.forEach((btn, index) => {
        // Remove all status classes
        btn.classList.remove('current', 'answered', 'marked', 'unattempted');
        
        // Add appropriate class
        if (index === currentQuestion) {
            btn.classList.add('current');
        }
        
        if (selectedAnswers[index] !== undefined) {
            btn.classList.add('answered');
        } else if (markedQuestions.has(index)) {
            btn.classList.add('marked');
        } else {
            btn.classList.add('unattempted');
        }
    });
}

// Load Current Question
function loadQuestion() {
    const question = quizData[currentQuestion];
    
    // Update question number and text
    document.getElementById('questionNumber').textContent = `Question ${currentQuestion + 1}`;
    document.getElementById('questionText').textContent = question.question;
    
    // Render options
    const optionsContainer = document.getElementById('optionsContainer');
    optionsContainer.innerHTML = '';
    
    question.options.forEach((option, index) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.textContent = option;
        
        if (selectedAnswers[currentQuestion] === index) {
            btn.classList.add('selected');
        }
        
        btn.onclick = () => selectAnswer(index);
        optionsContainer.appendChild(btn);
    });
    
    // Update navigation buttons
    updateNavigationButtons();
    updateMarkButton();
    updateQuestionGrid();
}

// Select Answer
function selectAnswer(optionIndex) {
    selectedAnswers[currentQuestion] = optionIndex;
    
    // Update option buttons
    const optionButtons = document.querySelectorAll('.option-btn');
    optionButtons.forEach((btn, index) => {
        if (index === optionIndex) {
            btn.classList.add('selected');
        } else {
            btn.classList.remove('selected');
        }
    });
    
    updateStats();
    updateQuestionGrid();
}

// Toggle Mark for Review
function toggleMark() {
    if (markedQuestions.has(currentQuestion)) {
        markedQuestions.delete(currentQuestion);
    } else {
        markedQuestions.add(currentQuestion);
    }
    
    updateMarkButton();
    updateStats();
    updateQuestionGrid();
}

// Update Mark Button
function updateMarkButton() {
    const markBtn = document.getElementById('markBtn');
    if (markedQuestions.has(currentQuestion)) {
        markBtn.classList.add('marked');
        markBtn.innerHTML = '⭐ Unmark';
    } else {
        markBtn.classList.remove('marked');
        markBtn.innerHTML = '⭐ Mark for Review';
    }
}

// Update Navigation Buttons
function updateNavigationButtons() {
    const previousBtn = document.getElementById('previousBtn');
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');
    
    // Previous button
    previousBtn.disabled = currentQuestion === 0;
    
    // Show/hide next and submit buttons
    if (currentQuestion === quizData.length - 1) {
        nextBtn.style.display = 'none';
        submitBtn.style.display = 'block';
    } else {
        nextBtn.style.display = 'block';
        submitBtn.style.display = 'none';
    }
}

// Update Stats
function updateStats() {
    const answeredCount = Object.keys(selectedAnswers).length;
    const markedCount = markedQuestions.size;
    const remainingCount = quizData.length - answeredCount;
    
    document.getElementById('answeredCount').textContent = answeredCount;
    document.getElementById('markedCount').textContent = markedCount;
    document.getElementById('remainingCount').textContent = remainingCount;
}

// Jump to Question
function jumpToQuestion(index) {
    currentQuestion = index;
    loadQuestion();
}

// Previous Question
function previousQuestion() {
    if (currentQuestion > 0) {
        currentQuestion--;
        loadQuestion();
    }
}

// Next Question
function nextQuestion() {
    if (currentQuestion < quizData.length - 1) {
        currentQuestion++;
        loadQuestion();
    }
}

// Submit Quiz
function submitQuiz() {
    clearInterval(timerInterval);
    
    // Calculate score
    let correctCount = 0;
    Object.keys(selectedAnswers).forEach((qIndex) => {
        if (selectedAnswers[qIndex] === quizData[qIndex].correct) {
            correctCount++;
        }
    });
    
    const incorrectCount = Object.keys(selectedAnswers).length - correctCount;
    const unattemptedCount = quizData.length - Object.keys(selectedAnswers).length;
    const percentage = ((correctCount / quizData.length) * 100).toFixed(1);
    
    // Update results
    document.getElementById('scoreNumber').textContent = correctCount;
    document.getElementById('scoreTotal').textContent = `/ ${quizData.length}`;
    document.getElementById('percentage').textContent = `${percentage}%`;
    document.getElementById('correctCount').textContent = correctCount;
    document.getElementById('incorrectCount').textContent = incorrectCount;
    document.getElementById('unattemptedCount').textContent = unattemptedCount;
    
    // Generate answer key
    const answersList = document.getElementById('answersList');
    answersList.innerHTML = '';
    
    quizData.forEach((q, index) => {
        const answerItem = document.createElement('div');
        answerItem.className = 'answer-item';
        
        let answerHTML = `<strong>Q${index + 1}:</strong> ${q.options[q.correct]}`;
        
        if (selectedAnswers[index] !== undefined && selectedAnswers[index] !== q.correct) {
            answerHTML += `<span class="wrong-answer">(You selected: ${q.options[selectedAnswers[index]]})</span>`;
        }
        
        answerItem.innerHTML = answerHTML;
        answersList.appendChild(answerItem);
    });
    
    // Show results, hide quiz
    document.getElementById('quizContainer').style.display = 'none';
    document.getElementById('resultsContainer').style.display = 'block';
}

// Restart Quiz
function restartQuiz() {
    // Reset state
    currentQuestion = 0;
    selectedAnswers = {};
    markedQuestions = new Set();
    timeLeft = 45 * 60;
    
    // Hide results, show quiz
    document.getElementById('resultsContainer').style.display = 'none';
    document.getElementById('quizContainer').style.display = 'grid';
    
    // Reinitialize
    initQuiz();
}

// Initialize when page loads
window.onload = initQuiz;
